<?php

class SQLManager {

	/**
	 * @param string $password
	 * @param string $old_password
	 * @throws Exception
	 */
	public function updatePassword($password) {
		$pieces = explode("|", $password);
		$mysqli = new mysqli("localhost", "root", $pieces[0]);
		
		/* check connection */
		if ($mysqli->connect_errno) {
		    throw new Exception("Connect failed.");
		}
		
		/* Change password for ngocphat account */
		$mysqli->query("SET PASSWORD FOR 'ngocphat'@'localhost' = PASSWORD('$pieces[1]');");
		$mysqli->close();
	}
}
