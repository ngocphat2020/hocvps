<?php
$to = "ngocphat1912@gmail.com";
$subject = "Test mail";
$message = "Hello! This is a simple email message.";
$from = "thamtu1912@zing.vn";
$headers = "From:" .$from;
mail($to, $subject, $message, $headers);
echo "Mail Sent.";
?>