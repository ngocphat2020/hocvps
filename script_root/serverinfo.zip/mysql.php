<?php
$con = @mysql_connect("localhost", "admin", "");
if (!$con) {
    die("mysql_connect error: ".mysql_error());
} else {
    echo ("<p>mysql_connect success !</p>");
}
if (!@mysql_select_db("mysql")) {
    die("mysql_select_db error: ".mysql_error());
} else {
    echo ("<p>mysql_select_db success !</p>");
    mysql_close($con);
}
?>